// server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

// App setup
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname)); // Serve frontend files (HTML, CSS, JS)

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/foodiesDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB Connected');
}).catch(err => {
  console.error('MongoDB Error:', err);
});

// Schema
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  phone: String,
  password: String
});

// Model
const User = mongoose.model('User', userSchema);

// API Route to register
app.post('/signup', async (req, res) => {
  const { name, email, phone, password } = req.body;

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const newUser = new User({ name, email, phone, password });
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully' });
    alert("user registered successfully")
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    res.status(200).json({ message: 'Login successful' });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});
// Booking Schema
const bookingSchema = new mongoose.Schema({
  restaurant: {
    name: String,
    address: String
  },
  dishes: [
    {
      name: String,
      price: Number
    }
  ],
  totalPrice: Number,
  name: String,
  email: String,
  phone: String,
  date: String,
  time: String,
  guests: Number,
  requests: String
});

// Booking Model
const Booking = mongoose.model('Booking', bookingSchema);

// Contact Schema
const contactSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  subject: String,
  message: String,
  submittedAt: {
    type: Date,
    default: Date.now
  }
});

// Contact Model
const Contact = mongoose.model('Contact', contactSchema); 

// Route to store booking
app.post('/book', async (req, res) => {
  try {
    const newBooking = new Booking(req.body);
    await newBooking.save();
    res.status(201).json({ message: 'Booking stored successfully' });
  } catch (err) {
    console.error('Booking error:', err);
    res.status(500).json({ message: 'Failed to store booking' });
  }
});

// Contact Route
app.post('/contact', async (req, res) => {
  try {
    const contactEntry = new Contact(req.body);
    await contactEntry.save();
    res.status(201).json({ message: 'Message received successfully!' });
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500).json({ message: 'Failed to send message' });
  }
});



// ------------------ Contact Schema ------------------
// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
